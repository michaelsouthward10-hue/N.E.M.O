# NEMO

NEMO is a local command-line assistant for an Obsidian vault. It searches the vault index and asks a local Ollama model to answer from matching notes. Relationship questions use the vault's `[[wikilinks]]` graph. NEMO can also draft a Markdown note and save it into the configured vault.

## Setup on Windows

1. Install Python 3.10 or newer and [Ollama](https://ollama.com/), then make sure the configured model is available (`qwen3:8b` by default).
2. Open `config/settings.yaml` and set `vault.path` to your Obsidian vault folder. The default is `D:/Obsidian/The Legend Of The Archangel`.
3. In a terminal, open the NEMO folder and run:

   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   $env:PYTHONPATH = "src"
   python -m nemo.cli
   ```

Keep Ollama running while using NEMO. At the first prompt, type `reindex` to build your private local index before asking questions. Type `reindex` again after changing notes in Obsidian; indexing creates summaries with Ollama and refreshes the local search and relationship data.

## Ask and create

- Ask normally, for example: `Who is Michael?`
- Ask for a relationship, for example: `How is Michael connected to Lucifer?`
- Create a note with `new note: Michael's abilities` or `/note Michael's abilities`. NEMO uses matching indexed vault notes as context and writes a new `.md` file into the configured vault. Existing files are left unchanged.

The local search index is `data/index.json`. It contains note text and summaries, is created by `reindex`, and is excluded from Git and release packages.
